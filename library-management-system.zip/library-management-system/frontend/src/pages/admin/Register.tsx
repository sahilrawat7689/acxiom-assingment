// components
import SignUp from '@/components/Auth';

const Register = () => {
    return (
        <div>
            <SignUp />
        </div>
    );
};

export default Register;
